package question1;
/**
 * Decrivez votre classe PilePleineException ici.
 * 
 * @author (votre nom) 
 * @version (un numero de version ou une date)
 */
public class PileVideException extends Exception{}

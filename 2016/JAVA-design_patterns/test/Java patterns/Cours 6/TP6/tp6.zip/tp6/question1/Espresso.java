package question1;
/**
 * extrait de http://www.oreilly.com/catalog/hfdesignpat/
 */
public class Espresso extends Beverage {
  
	public Espresso() {
		description = "Espresso";
	}
  
	public double cost() {
		return 1.99;
	}
	
}


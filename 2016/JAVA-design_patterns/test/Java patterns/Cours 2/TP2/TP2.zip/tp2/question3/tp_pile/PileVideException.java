package question3.tp_pile;

/**
 * Decrivez votre classe PilePleineException ici.
 * 
 * @author (votre nom) 
 * @version (un numero de version ou une date)
 */
public class PileVideException extends Exception
{

  public PileVideException()
  {
    super();
  }

  public PileVideException( String message )
  {
    super( message );
  }
} // PileVideException

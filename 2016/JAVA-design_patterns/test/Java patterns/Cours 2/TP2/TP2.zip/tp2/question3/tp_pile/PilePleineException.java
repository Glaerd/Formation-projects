package question3.tp_pile;

/**
 * Decrivez votre classe PilePleineException ici.
 * 
 * @author (votre nom) 
 * @version (un numero de version ou une date)
 */
public class PilePleineException extends Exception
{

  public PilePleineException()
  {
    super();
  }

  public PilePleineException( String message )
  {
    super( message );
  }
} // PilePleineException

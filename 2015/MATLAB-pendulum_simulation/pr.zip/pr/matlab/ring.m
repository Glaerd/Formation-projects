clear
close
 
global omega
omega = 10;

tmin=0;
tmax=40;
y20 = 0;
y30 = 0;


for y10 = 1.99
[t, y] = ode45 ('ring_fonction', [tmin tmax], [y10 y20] );
y1 = y(:,1);
y2 = y(:,2);
 
figure(1)
hold all;
plot(t, y1)     % graph : y1(t)
axis([tmin tmax -pi pi])
xlabel('temps (s)');
ylabel('position  \theta(t)')

figure(2)
hold all;
plot(t,y2)	    % graph : y2(t)
xlabel('temps (s)');
ylabel('vitesse : d\theta/dt')

end
hold off;



function dy=ring_fonction(t,y)
global omega;

  % variables d'�tat y
  %   y(1) est theta
  %   y(2) est la d�riv�e de theta
  % �tat d�riv�e
  %   dy(1) est le calcul de th�ta point
  %   dy(2) est le calcul de th�ta point point
 
  dy=zeros(2,1); % pour initialiser le vecteur dy
  
  dy(1) = y(2);
  
  % Equation sans frottement
  dy(2) = - sin(y(1)) + omega*omega*sin(y(1))*cos(y(1));

  % Equation avec frottement avec amortissement

  %dy(2) = -alpha*y(2)+omega*omega*sin(y(1))*cos(y(1))-sin(y(1));

end